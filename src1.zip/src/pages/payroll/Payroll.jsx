import React, { useState } from 'react';
import { 
  FileText, 
  Download, 
  Printer, 
  DollarSign, 
  AlertCircle,
  CheckCircle,
  Calculator
} from 'lucide-react';

export default function Payroll() {
  return (
    <div className="space-y-6 h-full flex flex-col">
      {/* Header Actions */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center space-y-4 sm:space-y-0">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">Wage Sheet Generation</h2>
          <p className="text-slate-500 text-sm">Select period and site to process payroll</p>
        </div>
        <div className="flex space-x-3">
           <select className="px-4 py-2 border border-slate-300 rounded-lg bg-white text-slate-700">
            <option>February 2026</option>
            <option>January 2026</option>
          </select>
          <button className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium shadow-sm">
            <Calculator size={18} />
            <span>Process Wages</span>
          </button>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm relative overflow-hidden">
          <div className="absolute top-0 right-0 p-4 opacity-10">
            {/* <DollarSign size={64} className="text-blue-600" /> */}
          </div>
          <p className="text-sm font-medium text-slate-500">Total Payout (Est.)</p>
          <h3 className="text-3xl font-bold text-slate-900 mt-2">₹ 42,50,000</h3>
          <div className="mt-4 flex items-center text-sm text-green-600">
            <CheckCircle size={16} className="mr-1" />
            <span>Includes PF & ESI contributions</span>
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
           <p className="text-sm font-medium text-slate-500">Deductions & Penalties</p>
          <h3 className="text-3xl font-bold text-red-600 mt-2">₹ 45,200</h3>
          <div className="mt-4 flex items-center text-sm text-red-600">
            <AlertCircle size={16} className="mr-1" />
            <span>12 Short Attendance Cases</span>
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
           <p className="text-sm font-medium text-slate-500">Compliance Status</p>
          <div className="flex space-x-4 mt-2">
            <div className="text-center">
                <div className="text-xs text-slate-500 mb-1">PF Challan</div>
                <span className="px-2 py-1 bg-yellow-100 text-yellow-800 rounded text-xs font-bold">Pending</span>
            </div>
            <div className="text-center">
                <div className="text-xs text-slate-500 mb-1">ESI Payment</div>
                 <span className="px-2 py-1 bg-yellow-100 text-yellow-800 rounded text-xs font-bold">Pending</span>
            </div>
            <div className="text-center">
                <div className="text-xs text-slate-500 mb-1">Bonus</div>
                 <span className="px-2 py-1 bg-green-100 text-green-800 rounded text-xs font-bold">Paid</span>
            </div>
          </div>
        </div>
      </div>

      {/* Detailed Sheet Preview */}
      <div className="bg-white border border-slate-200 rounded-xl flex-1 flex flex-col shadow-sm overflow-hidden">
        <div className="p-4 border-b border-slate-200 flex justify-between items-center bg-slate-50">
          <h3 className="font-semibold text-slate-800 flex items-center">
            <FileText size={18} className="mr-2 text-slate-500" />
            Wage Sheet Preview - All Sites
          </h3>
          <div className="flex space-x-2">
            {/* <button className="p-2 hover:bg-white rounded border border-transparent hover:border-slate-200 text-slate-500">
                <Printer size={18} />
            </button> */}
            {/* <button className="flex items-center space-x-2 px-3 py-1.5 border border-slate-300 rounded bg-white text-sm hover:bg-slate-50">
                <Download size={16} />
                <span>Export CSV</span>
            </button> */}
             <button className="flex items-center space-x-2 px-3 py-1.5 border border-slate-300 rounded bg-white text-sm hover:bg-slate-50">
                <Download size={16} />
                <span>Export Excel</span>
            </button>
          </div>
        </div>

        <div className="overflow-auto flex-1">
          <table className="w-full text-left border-collapse text-sm">
            <thead className="bg-slate-50 text-slate-500 font-medium border-b border-slate-200">
              <tr>
                <th className="px-4 py-3 sticky left-0 bg-slate-50 z-10 border-r border-slate-200">Employee</th>
                <th className="px-4 py-3 text-center">Days Worked</th>
                <th className="px-4 py-3 text-right">Basic + DA</th>
                <th className="px-4 py-3 text-right">HRA</th>
                <th className="px-4 py-3 text-right">Allowances</th>
                <th className="px-4 py-3 text-right">Gross Earnings</th>
                <th className="px-4 py-3 text-right text-red-600">PF (12%)</th>
                <th className="px-4 py-3 text-right text-red-600">ESI</th>
                <th className="px-4 py-3 text-right text-red-600">Penalties</th>
                <th className="px-4 py-3 text-right font-bold text-slate-900 bg-slate-50 sticky right-0">Net Pay</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {[1, 2, 3, 4, 5, 6, 7].map((i) => (
                <tr key={i} className="hover:bg-slate-50">
                  <td className="px-4 py-3 font-medium text-slate-900 sticky left-0 bg-white border-r border-slate-100">
                    <div>Ravi Sharma</div>
                    <div className="text-xs text-slate-500">EMP-20240{i}</div>
                  </td>
                  <td className="px-4 py-3 text-center">24.5</td>
                  <td className="px-4 py-3 text-right">18,500</td>
                  <td className="px-4 py-3 text-right">7,400</td>
                  <td className="px-4 py-3 text-right">2,100</td>
                  <td className="px-4 py-3 text-right font-medium">28,000</td>
                  <td className="px-4 py-3 text-right text-red-600">2,220</td>
                  <td className="px-4 py-3 text-right text-red-600">210</td>
                  <td className="px-4 py-3 text-right text-red-600">{i === 3 ? '500' : '-'}</td>
                  <td className="px-4 py-3 text-right font-bold text-slate-900 bg-slate-50 sticky right-0 border-l border-slate-100">
                    {i === 3 ? '25,070' : '25,570'}
                  </td>
                </tr>
              ))}
            </tbody>
            <tfoot className="bg-slate-50 font-bold border-t border-slate-200">
                 <tr>
                    <td className="px-4 py-3 sticky left-0 bg-slate-50 border-r border-slate-200">TOTAL</td>
                    <td className="px-4 py-3 text-center">-</td>
                    <td className="px-4 py-3 text-right">1,29,500</td>
                    <td className="px-4 py-3 text-right">51,800</td>
                    <td className="px-4 py-3 text-right">14,700</td>
                    <td className="px-4 py-3 text-right">1,96,000</td>
                    <td className="px-4 py-3 text-right text-red-600">15,540</td>
                    <td className="px-4 py-3 text-right text-red-600">1,470</td>
                    <td className="px-4 py-3 text-right text-red-600">500</td>
                    <td className="px-4 py-3 text-right sticky right-0 bg-slate-50 border-l border-slate-200">1,78,490</td>
                 </tr>
            </tfoot>
          </table>
        </div>
      </div>
    </div>
  );
}

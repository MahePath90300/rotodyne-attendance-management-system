import AdminSidebar from "./AdminSidebar";

export default function AdminLayout({ children }) {
  return (
    <div className="flex h-screen bg-slate-50">
      {/* LEFT SIDEBAR */}
      <AdminSidebar />

      {/* MAIN CONTENT AREA */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* TOP BAR */}
        <div className="h-16 bg-white border-b border-slate-200 flex items-center justify-between px-6">
          <h1 className="text-lg font-semibold text-slate-800">
            Executive Overview
          </h1>

          <div className="flex items-center gap-3">
            <span className="flex items-center gap-2 text-sm text-green-600">
              <span className="w-2 h-2 bg-green-500 rounded-full"></span>
              System Operational
            </span>
            <div className="w-8 h-8 bg-slate-200 rounded-full flex items-center justify-center font-bold">
              AD
            </div>
          </div>
        </div>

        {/* PAGE CONTENT */}
        <div className="flex-1 overflow-auto p-6">
          {children}
        </div>
      </div>
    </div>
  );
}

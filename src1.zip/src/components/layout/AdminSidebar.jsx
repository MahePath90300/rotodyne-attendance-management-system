import { useState } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { useAuth } from "../../context/AuthenticationContext";
import { 
  FileText, 
  Download, 
  Printer, 
  DollarSign, 
  AlertCircle,
  CheckCircle,
  Calculator,
  Menu,
  LayoutDashboard,
  Calendar,
  Users,
  Briefcase,
  LogOut,
  Settings
} from 'lucide-react';

export default function AdminSidebar() {
  const navigate = useNavigate();
  const location = useLocation();
  const { logout, user } = useAuth();

  const [isSidebarOpen, setIsSidebarOpen] = useState(true);

  const site = user?.site || "GADARWARA";

  const isActive = (path) => location.pathname.includes(path);

  const handleLogout = async () => {
    await logout();
    navigate("/", { replace: true });
  };

  return (
    <aside
      className={`bg-slate-900 text-white transition-all duration-300 ease-in-out flex flex-col ${
        isSidebarOpen ? "w-64" : "w-20"
      }`}
    >
      {/* Header */}
      <div className="p-4 border-b border-slate-800 flex items-center justify-between">
        {isSidebarOpen ? (
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center font-bold text-xl">
              R
            </div>
            <span className="font-bold text-lg tracking-tight">
              ROTODYNE
            </span>
          </div>
        ) : (
          <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center font-bold text-xl mx-auto">
            R
          </div>
        )}

        <button
          onClick={() => setIsSidebarOpen(!isSidebarOpen)}
          className="p-1 hover:bg-slate-800 rounded-md transition-colors"
        >
          <Menu size={20} />
        </button>
      </div>

      {/* Navigation */}
      <nav className="flex-1 py-6 overflow-y-auto">
        <ul className="space-y-1 px-2">

          <NavItem
            icon={<LayoutDashboard size={20} />}
            label="Dashboard"
            active={isActive("dashboard")}
            isOpen={isSidebarOpen}
            onClick={() => navigate(`/dashboard/${site}`)}
          />

          <NavItem
            icon={<Calendar size={20} />}
            label="Attendance"
            active={isActive("dashboard")}
            isOpen={isSidebarOpen}
            onClick={() => navigate(`/dashboard/${site}`)}
          />

          <NavItem
            icon={<Users size={20} />}
            label="HR & Employees"
            active={isActive("employees")}
            isOpen={isSidebarOpen}
            onClick={() => navigate("/employees")}
          />

          <NavItem
            icon={<FileText size={20} />}
            label="Payroll & Wages"
            active={isActive("payroll")}
            isOpen={isSidebarOpen}
            onClick={() => navigate("/payroll")}
          />

          <NavItem
            icon={<Briefcase size={20} />}
            label="Contract Mgmt"
            active={isActive("contracts")}
            isOpen={isSidebarOpen}
            onClick={() => navigate("/contracts")}
          />
        </ul>
      </nav>

      {/* Bottom Section */}
      <div className="p-4 border-t border-slate-800">
        <NavItem
          icon={<Settings size={20} />}
          label="Settings"
          active={isActive("settings")}
          isOpen={isSidebarOpen}
          onClick={() => navigate("/settings")}
        />

        <NavItem
          icon={<LogOut size={20} />}
          label="Logout"
          active={false}
          isOpen={isSidebarOpen}
          onClick={handleLogout}
          className="text-red-400 hover:text-red-300 hover:bg-red-900/20 mt-2"
        />
      </div>
    </aside>
  );
}

function NavItem({ icon, label, active, isOpen, onClick, className = "" }) {
  return (
    <li>
      <button
        onClick={onClick}
        className={`w-full flex items-center p-3 rounded-lg transition-all duration-200 group relative
          ${
            active
              ? "bg-blue-600 text-white shadow-md shadow-blue-900/20"
              : "text-slate-400 hover:bg-slate-800 hover:text-white"
          } ${className}`}
      >
        <span className="flex-shrink-0">{icon}</span>

        {isOpen && (
          <span className="ml-3 font-medium whitespace-nowrap overflow-hidden">
            {label}
          </span>
        )}

        {!isOpen && (
          <div className="absolute left-full ml-2 px-2 py-1 bg-slate-800 text-white text-xs rounded opacity-0 group-hover:opacity-100 pointer-events-none z-50 whitespace-nowrap">
            {label}
          </div>
        )}
      </button>
    </li>
  );
}

// import { Routes, Route, Navigate} from "react-router-dom";
// import Loginpage from './pages/Loginpage';
// import Dashboard from "./pages/Dashboard";
// import ProtectedRoute from "./components/ProtectedRoute";
// import AdminDashboard from "./pages/AdminDashboard";
// import EmployeeDirectory from "./pages/employee-kyc/EmployeeDirectory";
// import Attendance from "./pages/attendance";
// import Payroll from "./pages/payroll";

// function App() {
//   return (

//       <Routes>
//         <Route path="/" element={<Loginpage />} />
//         {/* site-specific dashboard */}
//         {/* <Route path="/dashboard"
//         element={<Navigate to="/dashboard/DADRI" replace />}
//         /> */}
//         {/* <Route
//           path="/dashboard/:siteId"
//           element={
//             <ProtectedRoute>
//               <Dashboard />
//             </ProtectedRoute>
//           }
//         /> */}
//         <Route path="/dashboard" element={<AdminDashboard />} />
//         <Route path="/employees" element={<EmployeeDirectory />} />
//         <Route path="/attendance" element={<Attendance />} />
//         <Route path="/payroll" element={<Payroll />} />

//       </Routes>
//   );
// }

// export default App;

// import React from 'react';
// import { BrowserRouter as Router, Routes, Route, useNavigate, useLocation } from 'react-router-dom';
// import { 
//   Users, 
//   Calendar, 
//   FileText, 
//   LayoutDashboard, 
//   Settings, 
//   LogOut, 
//   Menu,
//   Briefcase
// } from 'lucide-react';
// import ProtectedRoute from "./components/ProtectedRoute";

// import AdminDashboard from './pages/AdminDashboard';
// import  Employees from './pages/employee-kyc/EmployeeDirectory';
// import Dashboard from "./pages/Dashboard";
// import Attendance from './pages/attendance/Attendance';
// import Payroll from './pages/payroll/Payroll';
// import EmployeeDirectory from './pages/employee-kyc/EmployeeDirectory';
// import Loginpage from './pages/Loginpage';

// export default function App() {
//    return <MainLayout />;
// }
// function NavItem({ icon, label, active, isOpen, onClick, className = '' }) {
//   return (
//     <li>
//       <button
//         onClick={onClick}
//         className={`w-full flex items-center p-3 rounded-lg transition-all duration-200 group relative
//           ${active 
//             ? 'bg-blue-600 text-white shadow-md shadow-blue-900/20' 
//             : 'text-slate-400 hover:bg-slate-800 hover:text-white'
//           } ${className}`}
//       >
//         <span className="flex-shrink-0">{icon}</span>
//         {isOpen && (
//           <span className="ml-3 font-medium whitespace-nowrap overflow-hidden transition-all">
//             {label}
//           </span>
//         )}
//       </button>
//     </li>
//   );
// }

// function MainLayout() {
//   const navigate = useNavigate();
//   const location = useLocation();
//   const [isSidebarOpen, setIsSidebarOpen] = React.useState(true);

//   // Map active route to highlight sidebar
//   const getActiveTab = () => {
//     if (location.pathname.includes('/employees')) return 'employees';
//     if (location.pathname.includes('/attendance')) return 'attendance';
//     if (location.pathname.includes('/payroll')) return 'payroll';
//     return 'dashboard';
//   };

//   const activeTab = getActiveTab();

//   return (
//     <div className="flex h-screen bg-slate-50 text-slate-900 font-sans overflow-hidden">
//       {/* Sidebar */}
//       <aside 
//         className={`bg-slate-900 text-white transition-all duration-300 ease-in-out flex flex-col ${
//           isSidebarOpen ? 'w-64' : 'w-20'
//         }`}
//       >
//         <div className="p-4 border-b border-slate-800 flex items-center justify-between">
//           {isSidebarOpen ? (
//             <div className="flex items-center space-x-2">
//               <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center font-bold text-xl">R</div>
//               <span className="font-bold text-lg tracking-tight">ROTODYNE</span>
//             </div>
//           ) : (
//             <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center font-bold text-xl mx-auto">R</div>
//           )}
//           <button 
//             onClick={() => setIsSidebarOpen(!isSidebarOpen)}
//             className="p-1 hover:bg-slate-800 rounded-md transition-colors"
//           >
//             <Menu size={20} />
//           </button>
//         </div>

//         <nav className="flex-1 py-6 overflow-y-auto">
//           <ul className="space-y-1 px-2">
//             <NavItem 
//               icon={<LayoutDashboard size={20} />} 
//               label="Dashboard" 
//               active={activeTab === 'dashboard'} 
//               isOpen={isSidebarOpen}
//               onClick={() => navigate('/dashboard')}
//             />
//             <NavItem 
//               icon={<Users size={20} />} 
//               label="HR & Employees" 
//               active={activeTab === 'employees'} 
//               isOpen={isSidebarOpen}
//               onClick={() => navigate('/employees')}
//             />
//             <NavItem 
//               icon={<Calendar size={20} />} 
//               label="Attendance" 
//               active={activeTab === 'attendance'} 
//               isOpen={isSidebarOpen}
//               onClick={() => navigate('/attendance')}
//             />
//             <NavItem 
//               icon={<FileText size={20} />} 
//               label="Payroll & Wages" 
//               active={activeTab === 'payroll'} 
//               isOpen={isSidebarOpen}
//               onClick={() => navigate('/payroll')}
//             />
//             <NavItem 
//               icon={<Briefcase size={20} />} 
//               label="Contract Mgmt" 
//               active={activeTab === 'contracts'} 
//               isOpen={isSidebarOpen}
//               onClick={() => navigate('/contracts')}
//             />
//           </ul>
//         </nav>

//         <div className="p-4 border-t border-slate-800">
//           <NavItem 
//             icon={<Settings size={20} />} 
//             label="Settings" 
//             active={false} 
//             isOpen={isSidebarOpen}
//             onClick={() => console.log('settings')}
//           />
//           <NavItem 
//             icon={<LogOut size={20} />} 
//             label="Logout" 
//             active={false} 
//             isOpen={isSidebarOpen}
//             onClick={() => console.log('logout')}
//             className="text-red-400 hover:text-red-300 hover:bg-red-900/20 mt-2"
//           />
//         </div>
//       </aside>

//       {/* Main Content */}
//       <main className="flex-1 flex flex-col min-w-0 overflow-hidden">
//         <header className="bg-white border-b border-slate-200 h-16 flex items-center justify-between px-6 shadow-sm z-10">
//           <h1 className="text-xl font-semibold text-slate-800">
//             {activeTab === 'dashboard' && 'Executive Overview'}
//             {activeTab === 'employees' && 'Employee Directory'}
//             {activeTab === 'attendance' && 'Attendance & Time Tracking'}
//             {activeTab === 'payroll' && 'Wage Sheet Generation'}
//             {activeTab === 'contracts' && 'Contract Management'}
//           </h1>
//           <div className="flex items-center space-x-4">
//             <div className="flex items-center space-x-2 text-sm text-slate-600 bg-slate-100 px-3 py-1.5 rounded-full">
//               <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></span>
//               <span>System Operational</span>
//             </div>
//             <div className="w-8 h-8 bg-slate-200 rounded-full flex items-center justify-center text-slate-600 font-medium">
//               AD
//             </div>
//           </div>
//         </header>

//         <div className="flex-1 overflow-auto p-6 bg-slate-50">
//           <Routes>
//             <Route path="/" element={<Loginpage />}/>
//             <Route path="/dashboard/:siteId" element={<ProtectedRoute> <Dashboard /></ProtectedRoute>}/> 
//             {/* <Route path="/" element={<AdminDashboard />} /> */}
//             <Route path="/dashboard" element={<AdminDashboard />} />
//             <Route path="/employees" element={<Employees />} />
//             <Route path="/attendance/:siteId" element={<Dashboard />} />
//             <Route path="/payroll" element={<Payroll />} />
//           </Routes>
//         </div>
//       </main>
//     </div>
//   );
// }

import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AuthProvider } from "./context/AuthenticationContext";

import ProtectedRoute from "./components/ProtectedRoute";

 import AdminDashboard from './pages/AdminDashboard';
 import  Employees from './pages/employee-kyc/EmployeeDirectory';
import Dashboard from "./pages/Dashboard";
import Attendance from './pages/attendance/Attendance';
import Payroll from './pages/payroll/Payroll';
import EmployeeDirectory from './pages/employee-kyc/EmployeeDirectory';
import Loginpage from './pages/Loginpage';
import { useAuth } from "./context/AuthenticationContext";
import Unauthorized from "./pages/Unauthorized";
import MainLayout from "./components/layout/MainLayout";

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Loginpage />} />

      <Route
        element={
          <ProtectedRoute>
            <MainLayout />
          </ProtectedRoute>
        }
      >
        <Route path="/dashboard/:siteId" element={<Dashboard />} />
      </Route>

      <Route path="/unauthorized" element={<Unauthorized />} />
    </Routes>
  );
}
